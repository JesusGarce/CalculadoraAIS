package Calc;

public class Calculadora {
    public Calculadora() {
        new Interfaz();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Calculadora();
    }
    
}